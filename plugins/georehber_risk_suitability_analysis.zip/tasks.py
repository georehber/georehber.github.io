# -*- coding: utf-8 -*-

import os
import numpy as np
from osgeo import gdal
from qgis.core import QgsProject, QgsRasterLayer


# ---------------------------------------------------
# Yardımcı: Rasterı referans gridine warp et
# ---------------------------------------------------

def _warp_to_ref(src_ds, ref_ds):
    gt = ref_ds.GetGeoTransform()
    return gdal.Warp(
        "",
        src_ds,
        format="MEM",
        dstSRS=ref_ds.GetProjection(),
        xRes=gt[1],
        yRes=abs(gt[5]),
        outputBounds=(
            gt[0],
            gt[3] + ref_ds.RasterYSize * gt[5],
            gt[0] + ref_ds.RasterXSize * gt[1],
            gt[3]
        ),
        resampleAlg=gdal.GRA_NearestNeighbour
    )


# ---------------------------------------------------
# GeoTIFF yaz
# ---------------------------------------------------

def _write_geotiff(path, arr, ref_ds, nodata=-9999):
    drv = gdal.GetDriverByName("GTiff")
    ds = drv.Create(
        path,
        ref_ds.RasterXSize,
        ref_ds.RasterYSize,
        1,
        gdal.GDT_Float32,
        ["COMPRESS=LZW"]
    )

    ds.SetGeoTransform(ref_ds.GetGeoTransform())
    ds.SetProjection(ref_ds.GetProjection())

    band = ds.GetRasterBand(1)
    band.WriteArray(arr)
    band.SetNoDataValue(nodata)
    band.FlushCache()
    ds = None


# ---------------------------------------------------
# ANA ANALİZ
# ---------------------------------------------------

def run_analysis_no_processing(state):
    out_dir = state["output_dir"]
    rasters = state["rasters"]
    breaks = state["breaks"]
    scores = state["scores"]
    weights = state["weights"]
    raster_types = state.get("raster_types", {})  # 🔑 YENİ

    if not (rasters and breaks and scores and weights):
        raise Exception("Eksik analiz parametresi var.")

    numerator = None
    denominator = None
    ref_ds = None

    # ------------------------------------------------
    # Raster döngüsü
    # ------------------------------------------------

    for rid in rasters:
        layer = QgsProject.instance().mapLayer(rid)
        src_path = layer.source().split("|")[0]
        src_ds = gdal.Open(src_path, gdal.GA_ReadOnly)

        if ref_ds is None:
            ref_ds = src_ds
        else:
            src_ds = _warp_to_ref(src_ds, ref_ds)

        band = src_ds.GetRasterBand(1)
        arr = band.ReadAsArray().astype(np.float32)
        nodata = band.GetNoDataValue()

        if nodata is not None:
            arr[arr == nodata] = np.nan

        rc = np.full(arr.shape, np.nan, dtype=np.float32)

        br = breaks[rid]
        sc = scores[rid]
        rtype = raster_types.get(rid, "continuous")  # varsayılan sürekli

        # ------------------------------------------------
        # RECLASSIFY
        # ------------------------------------------------

        if rtype == "categorical":
            # KATEGORİK: arr == kod
            for (a, b), s in zip(br, sc):
                code = a  # From = To = kod
                rc[arr == code] = float(s)

        else:
            # SÜREKLİ: From–To
            for (a, b), s in zip(br, sc):
                rc[(arr >= a) & (arr < b)] = float(s)

            # son sınıfı yukarı açık bırak
            if br:
                last_to = br[-1][1]
                rc[arr >= last_to] = float(sc[-1])

        # ------------------------------------------------
        # AĞIRLIKLANDIR
        # ------------------------------------------------

        w = weights[rid] / 100.0

        if numerator is None:
            numerator = np.zeros(rc.shape, dtype=np.float32)
            denominator = np.zeros(rc.shape, dtype=np.float32)

        valid = ~np.isnan(rc)
        numerator[valid] += rc[valid] * w
        denominator[valid] += w

    # ------------------------------------------------
    # WEIGHTED MEAN
    # ------------------------------------------------

    result = np.full(numerator.shape, np.nan, dtype=np.float32)
    valid = denominator > 0
    result[valid] = numerator[valid] / denominator[valid]

    # ------------------------------------------------
    # FINAL RASTER
    # ------------------------------------------------

    final = np.full(result.shape, -9999.0, dtype=np.float32)
    final[valid] = result[valid]

    # ------------------------------------------------
    # ÇIKTIYI YAZ + QGIS'E EKLE
    # ------------------------------------------------

    out_path = os.path.join(out_dir, "GeoRehber_Weighted_Overlay.tif")
    _write_geotiff(out_path, final, ref_ds)

    rl = QgsRasterLayer(out_path, "Weighted Overlay")
    if rl.isValid():
        QgsProject.instance().addMapLayer(rl)
    else:
        raise Exception("Çıktı raster QGIS'e eklenemedi.")

    return out_path
