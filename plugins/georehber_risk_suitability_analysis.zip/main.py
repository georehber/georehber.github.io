# -*- coding: utf-8 -*-

import os
from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon

from .wizard import GeoRehberWizard


class GeoRehberRiskSuitability:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.wizard = None

    def initGui(self):
        # icon yolu (plugin klasöründen)
        icon_path = os.path.join(
            os.path.dirname(__file__),
            "icon.png"
        )

        # QAction
        self.action = QAction(
            QIcon(icon_path),
            "Risk / Uygunluk Analizi",
            self.iface.mainWindow()
        )

        self.action.triggered.connect(self.run)

        # Menüye ekle (üst başlık: GeoRehber)
        self.iface.addPluginToMenu("&GeoRehber", self.action)

        # Toolbar'a ekle
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        # Menüden kaldır
        self.iface.removePluginMenu("&GeoRehber", self.action)

        # Toolbar'dan kaldır
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        # Eski wizard varsa tamamen kapat (RAM'de kalmasın)
        if self.wizard is not None:
            try:
                self.wizard.close()
                self.wizard.deleteLater()
            except Exception:
                pass
            self.wizard = None

        # Yeni wizard oluştur
        self.wizard = GeoRehberWizard(self.iface.mainWindow())
        self.wizard.show()

