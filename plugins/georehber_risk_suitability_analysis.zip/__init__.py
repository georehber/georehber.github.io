# -*- coding: utf-8 -*-

def classFactory(iface):
    """
    QGIS tarafından plugin yüklenirken çağrılır.
    """
    from .main import GeoRehberRiskSuitability
    return GeoRehberRiskSuitability(iface)
