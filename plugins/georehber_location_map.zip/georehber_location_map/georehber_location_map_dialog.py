# -*- coding: utf-8 -*-

from qgis.PyQt import QtWidgets, QtCore
from qgis.core import QgsProject, QgsMapLayer


class GeorehberLocationMapDialog(QtWidgets.QDialog):
    """
    Lokasyon haritası işlemi için arayüz.
    """

    def __init__(self, iface, parent=None):
        super().__init__(parent)

        self.iface = iface
        self.setWindowTitle("GeoRehber • Lokasyon Haritası")
        self.resize(480, 360)

        main_layout = QtWidgets.QVBoxLayout(self)

        # ---------------- 1) POLİGON KATMANI ----------------
        poly_group = QtWidgets.QGroupBox("1) Poligon katmanı")
        poly_layout = QtWidgets.QFormLayout(poly_group)

        self.poly_layer_combo = QtWidgets.QComboBox()
        self.field_combo = QtWidgets.QComboBox()

        # ❗ Yeni akıllı filtre kutusu (autocomplete + açılır kutu)
        self.value_edit = QtWidgets.QComboBox()
        self.value_edit.setEditable(True)
        self.value_edit.setInsertPolicy(QtWidgets.QComboBox.NoInsert)
        self.value_edit.lineEdit().setPlaceholderText("İsim yazın veya listeden seçin...")

        poly_layout.addRow("Katman:", self.poly_layer_combo)
        poly_layout.addRow("Ad alanı:", self.field_combo)
        poly_layout.addRow("Filtre değeri:", self.value_edit)

        # ---------------- 2) DEM KATMANI ----------------
        dem_group = QtWidgets.QGroupBox("2) DEM raster katmanı")
        dem_layout = QtWidgets.QFormLayout(dem_group)

        self.dem_layer_combo = QtWidgets.QComboBox()
        dem_layout.addRow("DEM:", self.dem_layer_combo)

        # ---------------- 3) ÇIKTI KLASÖRÜ ----------------
        out_group = QtWidgets.QGroupBox("3) Çıktı klasörü")
        out_layout = QtWidgets.QHBoxLayout(out_group)

        self.folder_edit = QtWidgets.QLineEdit()
        self.folder_edit.setPlaceholderText("GPKG buraya kaydedilecek")
        self.browse_btn = QtWidgets.QPushButton("Gözat...")

        out_layout.addWidget(self.folder_edit)
        out_layout.addWidget(self.browse_btn)

        # ---------------- Alt butonlar ----------------
        btn_layout = QtWidgets.QHBoxLayout()
        btn_layout.addStretch()
        self.run_btn = QtWidgets.QPushButton("İşlemleri Çalıştır")
        self.cancel_btn = QtWidgets.QPushButton("Kapat")
        btn_layout.addWidget(self.run_btn)
        btn_layout.addWidget(self.cancel_btn)

        # Layout
        main_layout.addWidget(poly_group)
        main_layout.addWidget(dem_group)
        main_layout.addWidget(out_group)
        main_layout.addStretch()
        main_layout.addLayout(btn_layout)

        # SIGNALS
        self.cancel_btn.clicked.connect(self.reject)
        self.browse_btn.clicked.connect(self.choose_folder)

        self.poly_layer_combo.currentIndexChanged.connect(self.refresh_fields)
        self.field_combo.currentIndexChanged.connect(self.refresh_field_values)

        self.refresh_layers()

    # -------------------------------------------------------------------
    # KATMAN DOLDURMA
    # -------------------------------------------------------------------

    def refresh_layers(self):
        """Projede poligon ve raster katmanlarını listele."""
        self.poly_layer_combo.clear()
        self.dem_layer_combo.clear()

        self._poly_ids = []
        self._dem_ids = []

        for layer in QgsProject.instance().mapLayers().values():

            # Poligon katman
            if (
                layer.type() == QgsMapLayer.VectorLayer
                and layer.geometryType() == 2
            ):
                self.poly_layer_combo.addItem(layer.name())
                self._poly_ids.append(layer.id())

            # Raster katman
            elif layer.type() == QgsMapLayer.RasterLayer:
                self.dem_layer_combo.addItem(layer.name())
                self._dem_ids.append(layer.id())

        self.refresh_fields()

    def current_poly_layer(self):
        idx = self.poly_layer_combo.currentIndex()
        if idx < 0 or idx >= len(self._poly_ids):
            return None
        return QgsProject.instance().mapLayer(self._poly_ids[idx])

    def current_dem_layer(self):
        idx = self.dem_layer_combo.currentIndex()
        if idx < 0 or idx >= len(self._dem_ids):
            return None
        return QgsProject.instance().mapLayer(self._dem_ids[idx])

    # -------------------------------------------------------------------
    # ALAN ADLARI VE ALAN DEĞERLERİ
    # -------------------------------------------------------------------

    def refresh_fields(self):
        """Poligon katmanındaki alan adlarını doldur."""
        self.field_combo.clear()
        layer = self.current_poly_layer()

        if not layer:
            return

        for field in layer.fields():
            self.field_combo.addItem(field.name())

        self.refresh_field_values()

    def refresh_field_values(self):
        """Seçili alandaki tüm benzersiz değerleri doldur."""
        layer = self.current_poly_layer()
        if not layer:
            return

        field_name = self.field_combo.currentText().strip()
        if not field_name:
            return

        values = set()
        for f in layer.getFeatures():
            v = f[field_name]
            if v is not None:
                values.add(str(v))

        values = sorted(values, key=lambda x: x.lower())

        self.value_edit.clear()
        self.value_edit.addItems(values)

        # autocomplete (yazdıkça filtreleme + case-insensitive)
        completer = QtWidgets.QCompleter(values)
        completer.setCaseSensitivity(False)
        completer.setFilterMode(QtCore.Qt.MatchContains)
        self.value_edit.setCompleter(completer)

    # -------------------------------------------------------------------
    # KLASÖR SEÇME
    # -------------------------------------------------------------------

    def choose_folder(self):
        folder = QtWidgets.QFileDialog.getExistingDirectory(
            self,
            "Çıktı klasörünü seç",
            ""
        )
        if folder:
            self.folder_edit.setText(folder)
