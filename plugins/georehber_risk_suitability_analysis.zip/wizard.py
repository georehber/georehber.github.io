# -*- coding: utf-8 -*-

from qgis.PyQt.QtWidgets import (
    QWizard, QWizardPage,
    QLabel, QVBoxLayout, QHBoxLayout,
    QLineEdit, QPushButton, QFileDialog,
    QComboBox, QWidget,
    QTableWidget, QTableWidgetItem,
    QSpinBox, QDoubleSpinBox, QMessageBox, QScrollArea
)
from qgis.PyQt.QtWidgets import QSpinBox
from qgis.PyQt.QtCore import Qt
from qgis.core import (
    QgsProject, QgsRasterLayer,
    QgsVectorLayer, QgsWkbTypes
)
from qgis.gui import QgsProjectionSelectionWidget
from osgeo import gdal
import numpy as np

from .tasks import run_analysis_no_processing


# ---------------------------------------------------
# PAGE 1 – SETUP
# ---------------------------------------------------

class SetupPage(QWizardPage):
    def __init__(self):
        super().__init__()
        self.setTitle("Genel Ayarlar")

        self.out_edit = QLineEdit()
        self.out_edit.setReadOnly(True)
        out_btn = QPushButton("Klasör Seç")
        out_btn.clicked.connect(self.pick_output)

        out_h = QHBoxLayout()
        out_h.addWidget(self.out_edit)
        out_h.addWidget(out_btn)

        self.aoi_combo = QComboBox()
        self.crs_widget = QgsProjectionSelectionWidget()

        v = QVBoxLayout()
        v.addWidget(QLabel("Çıktı klasörü:"))
        v.addLayout(out_h)

        v.addSpacing(15)
        v.addWidget(QLabel("Çalışma Alanı (AOI – Poligon):"))
        v.addWidget(self.aoi_combo)

        v.addSpacing(15)
        v.addWidget(QLabel("Hedef CRS:"))
        v.addWidget(self.crs_widget)

        v.addStretch()
        self.setLayout(v)

    def initializePage(self):
        self.aoi_combo.clear()
        self.aoi_combo.addItem("Seçin…", None)

        for l in QgsProject.instance().mapLayers().values():
            if isinstance(l, QgsVectorLayer) and \
               QgsWkbTypes.geometryType(l.wkbType()) == QgsWkbTypes.PolygonGeometry:
                self.aoi_combo.addItem(l.name(), l.id())

    def pick_output(self):
        p = QFileDialog.getExistingDirectory(self, "Çıktı Klasörü")
        if p:
            self.out_edit.setText(p)

    def validatePage(self):
        if not self.out_edit.text():
            return False
        if not self.aoi_combo.currentData():
            return False
        crs = self.crs_widget.crs()
        if not crs.isValid():
            return False

        self.wizard().state["output_dir"] = self.out_edit.text()
        self.wizard().state["aoi_layer_id"] = self.aoi_combo.currentData()
        self.wizard().state["target_crs"] = crs
        return True


# ---------------------------------------------------
# PAGE 2 – RASTER SELECTION
# ---------------------------------------------------

class RasterSelectionPage(QWizardPage):
    def __init__(self):
        super().__init__()
        self.setTitle("Raster Katman Seçimi")
        self.rows = []

        self.v = QVBoxLayout()
        self.add_row()
        self.v.addStretch()
        self.setLayout(self.v)

    def rasters(self):
        return [
            l for l in QgsProject.instance().mapLayers().values()
            if isinstance(l, QgsRasterLayer)
        ]

    def add_row(self):
        cb = QComboBox()
        cb.addItem("Raster seçin…", None)
        for r in self.rasters():
            cb.addItem(r.name(), r.id())
        cb.currentIndexChanged.connect(self.changed)
        self.v.insertWidget(self.v.count() - 1, cb)
        self.rows.append(cb)

    def changed(self):
        if self.rows[-1].currentData():
            self.add_row()

    def validatePage(self):
        sel = [r.currentData() for r in self.rows if r.currentData()]
        if not sel:
            return False
        self.wizard().state["rasters"] = sel
        return True


# ---------------------------------------------------
# PAGE 3 – BREAKS + SCORES (TEK TABLO)
# ---------------------------------------------------

class BreaksPage(QWizardPage):
    def __init__(self):
        super().__init__()
        self.setTitle("Breaks / Reclassify")

        self.tables = {}
        self.type_boxes = {}
        self.label_boxes = {}

        self.class_spin = QSpinBox()
        self.class_spin.setRange(2, 5)
        self.class_spin.setValue(5)
        self.class_spin.valueChanged.connect(self._rebuild)

        # -------- SAYFA SCROLL --------
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)

        self.container = QWidget()
        self.v = QVBoxLayout(self.container)
        self.scroll.setWidget(self.container)

        main = QVBoxLayout()
        main.addWidget(QLabel("Sınıf sayısı :"))
        main.addWidget(self.class_spin)
        main.addWidget(self.scroll)
        self.setLayout(main)

    # --------------------------------------------------
    # Lifecycle
    # --------------------------------------------------

    def initializePage(self):
        self._rebuild()

    def _rebuild(self):
        while self.v.count():
            w = self.v.takeAt(0).widget()
            if w:
                w.deleteLater()

        self.tables.clear()
        self.type_boxes.clear()
        self.label_boxes.clear()

        n = self.class_spin.value()

        for rid in self.wizard().state["rasters"]:
            raster = QgsProject.instance().mapLayer(rid)

            # -------- BAŞLIK --------
            h = QHBoxLayout()
            lbl = QLabel(raster.name())
            lbl.setStyleSheet("font-weight:bold;")
            h.addWidget(lbl)
            h.addStretch()

            h.addWidget(QLabel("Tür:"))
            type_cb = QComboBox()
            type_cb.addItem("Sürekli", "continuous")
            type_cb.addItem("Kategorik", "categorical")
            type_cb.currentIndexChanged.connect(
                lambda _=None, rrid=rid: self._apply_type(rrid)
            )
            self.type_boxes[rid] = type_cb
            h.addWidget(type_cb)

            hw = QWidget()
            hw.setLayout(h)
            self.v.addWidget(hw)

            # -------- TABLO (varsayılan: sürekli) --------
            t = QTableWidget(n, 3)
            t.setHorizontalHeaderLabels(["From", "To", "Puan"])
            t.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
            t.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
            t.horizontalHeader().setStretchLastSection(True)

            for i, (a, b) in enumerate(self._auto_breaks(raster, n)):
                t.setItem(i, 0, QTableWidgetItem(str(a)))
                t.setItem(i, 1, QTableWidgetItem(str(b)))

                sp = QSpinBox()
                sp.setRange(-999999999, 999999999)
                sp.setValue(1)
                t.setCellWidget(i, 2, sp)

            self._fit_table_height(t)

            self.tables[rid] = t
            self.v.addWidget(t)

            # -------- SINIF ADI SÜTUNU (GİZLİ) --------
            lh = QHBoxLayout()
            lh.addWidget(QLabel("Sınıf Adı Sütunu:"))

            lcb = QComboBox()
            lcb.currentIndexChanged.connect(
                lambda _=None, rrid=rid: self._build_categorical_table(rrid)
            )
            self.label_boxes[rid] = lcb
            lh.addWidget(lcb)

            lw = QWidget()
            lw.setLayout(lh)
            lw.setVisible(False)
            lw.setObjectName(f"label_wrap_{rid}")
            self.v.addWidget(lw)

            self.v.addSpacing(14)

        self.v.addStretch()

    # --------------------------------------------------
    # Tür değişimi
    # --------------------------------------------------

    def _apply_type(self, rid):
        t = self.tables[rid]
        raster = QgsProject.instance().mapLayer(rid)
        rtype = self.type_boxes[rid].currentData()
        lw = self._find_label_wrap(rid)

        if rtype == "continuous":
            lw.setVisible(False)
            n = self.class_spin.value()

            t.clear()
            t.setColumnCount(3)
            t.setHorizontalHeaderLabels(["From", "To", "Puan"])
            t.setRowCount(n)

            for i, (a, b) in enumerate(self._auto_breaks(raster, n)):
                t.setItem(i, 0, QTableWidgetItem(str(a)))
                t.setItem(i, 1, QTableWidgetItem(str(b)))

                sp = QSpinBox()
                sp.setRange(-999999999, 999999999)
                sp.setValue(1)
                t.setCellWidget(i, 2, sp)

            self._fit_table_height(t)

        else:
            lw.setVisible(True)
            self._populate_label_columns(rid)
            self._build_categorical_table(rid)

    # --------------------------------------------------
    # Kategorik
    # --------------------------------------------------

    def _populate_label_columns(self, rid):
        cb = self.label_boxes[rid]
        cb.clear()

        raster = QgsProject.instance().mapLayer(rid)
        cols = self._get_rat_string_columns(raster)
        for c in cols:
            cb.addItem(c)

    def _build_categorical_table(self, rid):
        t = self.tables[rid]
        raster = QgsProject.instance().mapLayer(rid)

        labels = self._read_rat_labels(rid)
        codes = self._unique_codes(raster)

        t.clear()
        t.setColumnCount(4)
        t.setHorizontalHeaderLabels(["From", "To", "Sınıf Adı", "Puan"])
        t.setRowCount(len(codes))

        for i, code in enumerate(codes):
            t.setItem(i, 0, QTableWidgetItem(str(code)))
            t.setItem(i, 1, QTableWidgetItem(str(code)))
            t.setItem(i, 2, QTableWidgetItem(labels.get(code, "")))

            sp = QSpinBox()
            sp.setRange(-999999999, 999999999)
            sp.setValue(1)
            t.setCellWidget(i, 3, sp)

        self._fit_table_height(t)

    # --------------------------------------------------
    # RAT
    # --------------------------------------------------

    def _get_rat_string_columns(self, raster_layer):
        path = raster_layer.source().split("|")[0]
        ds = gdal.Open(path)
        band = ds.GetRasterBand(1)
        rat = band.GetDefaultRAT()
        if rat is None:
            return []

        out = []
        for i in range(rat.GetColumnCount()):
            if rat.GetTypeOfCol(i) == gdal.GFT_String:
                out.append(rat.GetNameOfCol(i))
        return out

    def _read_rat_labels(self, rid):
        raster = QgsProject.instance().mapLayer(rid)
        col = self.label_boxes[rid].currentText()
        if not col:
            return {}

        path = raster.source().split("|")[0]
        ds = gdal.Open(path)
        band = ds.GetRasterBand(1)
        rat = band.GetDefaultRAT()
        if rat is None:
            return {}

        val_col = None
        lbl_col = None
        for i in range(rat.GetColumnCount()):
            name = rat.GetNameOfCol(i)
            if name.lower() in ("value", "code"):
                val_col = i
            if name == col:
                lbl_col = i

        if val_col is None or lbl_col is None:
            return {}

        out = {}
        for r in range(rat.GetRowCount()):
            out[rat.GetValueAsInt(r, val_col)] = rat.GetValueAsString(r, lbl_col)
        return out

    # --------------------------------------------------
    # Yardımcılar
    # --------------------------------------------------

    def _unique_codes(self, raster_layer):
        path = raster_layer.source().split("|")[0]
        ds = gdal.Open(path)
        band = ds.GetRasterBand(1)
        arr = band.ReadAsArray().astype(np.float32)

        nodata = band.GetNoDataValue()
        if nodata is not None:
            arr[arr == nodata] = np.nan

        arr[arr == 0] = np.nan  # arka plan temizle
        uniq = np.unique(arr[~np.isnan(arr)])
        return [int(round(v)) for v in uniq.tolist()]

    def _auto_breaks(self, raster_layer, n):
        path = raster_layer.source().split("|")[0]
        ds = gdal.Open(path)
        band = ds.GetRasterBand(1)
        arr = band.ReadAsArray().astype(np.float32)

        nodata = band.GetNoDataValue()
        if nodata is not None:
            arr[arr == nodata] = np.nan

        valid = arr[~np.isnan(arr)]
        vmin, vmax = float(valid.min()), float(valid.max())
        step = (vmax - vmin) / n

        return [
            (
                round(vmin + i * step, 6),
                round(vmax if i == n - 1 else vmin + (i + 1) * step, 6)
            )
            for i in range(n)
        ]

    def _fit_table_height(self, t):
        t.resizeRowsToContents()
        t.resizeColumnsToContents()

        h = t.horizontalHeader().height()
        for i in range(t.rowCount()):
            h += t.rowHeight(i)

        t.setMinimumHeight(h + 6)

    def _find_label_wrap(self, rid):
        for i in range(self.v.count()):
            w = self.v.itemAt(i).widget()
            if w and w.objectName() == f"label_wrap_{rid}":
                return w
        return QWidget()

    # --------------------------------------------------
    # Validate
    # --------------------------------------------------

    def validatePage(self):
        breaks = {}
        scores = {}
        rtypes = {}

        for rid, t in self.tables.items():
            rtype = self.type_boxes[rid].currentData()
            rtypes[rid] = rtype

            br = []
            sc = []

            for r in range(t.rowCount()):
                a = float(t.item(r, 0).text())
                b = float(t.item(r, 1).text())

                if rtype == "continuous" and a >= b:
                    QMessageBox.warning(self, "Uyarı", "From < To olmalıdır.")
                    return False
                if rtype == "categorical" and a != b:
                    QMessageBox.warning(self, "Uyarı", "Kategorikte From = To olmalıdır.")
                    return False

                br.append((a, b))
                puan_col = 3 if rtype == "categorical" else 2
                sc.append(int(t.cellWidget(r, puan_col).value()))

            breaks[rid] = br
            scores[rid] = sc

        self.wizard().state["breaks"] = breaks
        self.wizard().state["scores"] = scores
        self.wizard().state["raster_types"] = rtypes
        return True



# ---------------------------------------------------
# PAGE 4 – WEIGHTS
# ---------------------------------------------------

class WeightsPage(QWizardPage):
    def __init__(self):
        super().__init__()
        self.setTitle("Ağırlıklar")
        self.setSubTitle("Toplam %100 olmalıdır.")
        self.spins = {}

        self.v = QVBoxLayout()
        self.total_lbl = QLabel()
        self.v.addWidget(self.total_lbl)
        self.setLayout(self.v)

    def initializePage(self):
        self.spins.clear()

        while self.v.count() > 1:
            item = self.v.takeAt(1)
            w = item.widget()
            if w:
                w.deleteLater()

        for rid in self.wizard().state["rasters"]:
            lyr = QgsProject.instance().mapLayer(rid)
            self.v.addWidget(QLabel(lyr.name()))

            s = QDoubleSpinBox()
            s.setRange(0.0, 100.0)
            s.setDecimals(2)
            s.setSingleStep(1.0)
            s.setSuffix(" %")
            s.valueChanged.connect(self._update)

            self.spins[rid] = s
            self.v.addWidget(s)

        self._update()
        self.v.addStretch()

    def _update(self):
        total = sum(s.value() for s in self.spins.values())
        self.total_lbl.setText(f"Toplam: {total:.2f} %")

    def validatePage(self):
        total = sum(s.value() for s in self.spins.values())
        if abs(total - 100.0) > 0.05:
            QMessageBox.warning(self, "Uyarı", f"Ağırlıklar %100 olmalıdır. ({total:.2f}%)")
            return False

        self.wizard().state["weights"] = {
            rid: s.value() for rid, s in self.spins.items()
        }
        return True


# ---------------------------------------------------
# WIZARD
# ---------------------------------------------------

class GeoRehberWizard(QWizard):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.state = {}

        self.setWizardStyle(QWizard.ClassicStyle)
        self.setWindowTitle("GeoRehber Risk / Uygunluk Analizi")
        self.resize(900, 650)

        self.addPage(SetupPage())
        self.addPage(RasterSelectionPage())
        self.addPage(BreaksPage())
        self.addPage(WeightsPage())

    def accept(self):
        if not self.validateCurrentPage():
            return

        if "weights" not in self.state:
            QMessageBox.critical(self, "Hata", "Ağırlıklar kaydedilemedi.")
            return

        try:
            run_analysis_no_processing(self.state)
            QMessageBox.information(self, "GeoRehber", "Analiz tamamlandı.")
            super().accept()
        except Exception as e:
            QMessageBox.critical(self, "Hata", str(e))
    
    def reject(self):
        """
        Wizard kapatıldığında (X veya Cancel),
        state tamamen temizlensin ve wizard yok edilsin.
        """
        self.state.clear()
        self.deleteLater()
        super().reject()

