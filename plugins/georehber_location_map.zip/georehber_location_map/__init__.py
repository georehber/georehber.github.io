# -*- coding: utf-8 -*-
"""
QGIS Plugin initialization file
"""

def classFactory(iface):
    """QGIS plugin entry point."""
    from .georehber_location_map import GeorehberLocationMapPlugin
    return GeorehberLocationMapPlugin(iface)
