# -*- coding: utf-8 -*-

import os
import re

from qgis.PyQt.QtCore import QCoreApplication
from qgis.PyQt.QtWidgets import QAction, QMessageBox
from qgis.PyQt.QtGui import QColor


from qgis.core import (
    QgsProject,
    QgsExpression,
    QgsFeatureRequest,
    QgsVectorFileWriter,
    QgsCoordinateTransformContext,
    QgsProcessingFeedback,
    QgsRasterLayer,
    QgsVectorLayer,
    QgsPrintLayout,
    QgsLayoutItemMap,
    QgsLayoutPoint,
    QgsLayoutSize,
    QgsUnitTypes,
    QgsLayoutExporter,
    QgsLayoutItemPage,
    QgsLayoutMeasurement,
    QgsRasterShader,
    QgsColorRampShader,
    QgsSingleBandPseudoColorRenderer,
    QgsRectangle,
    Qgis,
    QgsLayoutItemPicture,
    QgsLayoutItemScaleBar,
    QgsLayoutItemLegend,
    QgsApplication
)


from qgis.utils import iface as global_iface
from qgis import processing

from .georehber_location_map_dialog import GeorehberLocationMapDialog


class GeorehberLocationMapPlugin:
    """GeoRehber Lokasyon haritası eklentisi."""

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.action = None
        self.dialog = None

    def initGui(self):
        self.action = QAction("GeoRehber • Lokasyon", self.iface.mainWindow())
        self.action.setWhatsThis("Çalışma alanı otomasyonu.")
        self.action.triggered.connect(self.run)

        self.iface.addPluginToMenu("GeoRehber Lokasyon Haritası", self.action)
        self.iface.addToolBarIcon(self.action)

    def unload(self):
        if self.action:
            self.iface.removePluginMenu("GeoRehber Lokasyon Haritası", self.action)
            self.iface.removeToolBarIcon(self.action)

    def run(self):
        if not self.dialog:
            self.dialog = GeorehberLocationMapDialog(self.iface, self.iface.mainWindow())

        self.dialog.refresh_layers()

        try:
            self.dialog.run_btn.clicked.disconnect()
        except Exception:
            pass
        self.dialog.run_btn.clicked.connect(self.handle_run)

        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()

    def handle_run(self):
        # ------------------------------------------------------------------
        # 1) DİYALOĞTAN GİRDİLERİ AL
        # ------------------------------------------------------------------
        poly_layer = self.dialog.current_poly_layer()
        dem_layer = self.dialog.current_dem_layer()
        field_name = self.dialog.field_combo.currentText().strip()
        value_text = self.dialog.value_edit.currentText().strip()

        out_folder = self.dialog.folder_edit.text().strip()

        if not poly_layer:
            self._msg("Lütfen bir poligon katmanı seç.", error=True)
            return

        if not dem_layer:
            self._msg("Lütfen bir DEM raster katmanı seç.", error=True)
            return

        if not field_name:
            self._msg("Lütfen ad alanını seç.", error=True)
            return

        if not value_text:
            self._msg("Lütfen bir filtre değeri gir.", error=True)
            return

        if not out_folder or not os.path.isdir(out_folder):
            self._msg("Geçerli bir çıktı klasörü seç.", error=True)
            return

        safe_name = self._sanitize_name(value_text)
        gpkg_path = os.path.join(out_folder, f"{safe_name}.gpkg")

        project = QgsProject.instance()
        
        # --- ESKİ VERİ PROJEDE AÇIK MI? SADECE BUNA BAK! ---
        def is_layer_open(file_path):
            file_path_norm = file_path.replace("\\", "/")
            for lyr in project.mapLayers().values():
                try:
                    src = lyr.source().replace("\\", "/")
                except:
                    continue
                if file_path_norm in src:
                    return True
            return False

        # KONTROL EDİLECEK DOSYALAR
        dem_clip_path = os.path.join(out_folder, f"{safe_name}_dem_clip.tif")
        hill_path = os.path.join(out_folder, f"{safe_name}_hillshade.tif")

        # Eğer proje içinde AÇIKSA → UYARI VER, işlemi durdur
        if is_layer_open(gpkg_path):
            self._msg(
                "Alan katmanı QGIS'te açık, bu nedenle üzerine yazılamıyor.\n"
                "Lütfen eski katmanı projeden kaldırın.",
                error=True
            )
            return

        if is_layer_open(dem_clip_path):
            self._msg(
                "DEM Clip rasterı projede açık, üzerine yazılamıyor.\n"
                "Lütfen katmanı projeden kaldırın.",
                error=True
            )
            return

        if is_layer_open(hill_path):
            self._msg(
                "Hillshade rasterı projede açık, üzerine yazılamıyor.\n"
                "Lütfen katmanı projeden kaldırın.",
                error=True
            )
            return

        # ------------------------------------------------------------------
        # 2) İLÇE POLİGONUNU FİLTRELE VE GPKG'YE YAZ
        # ------------------------------------------------------------------
        expr_str = f'"{field_name}" ILIKE \'%{value_text}%\''
        expr = QgsExpression(expr_str)
        if expr.hasParserError():
            self._msg(f"İfade hatası: {expr.parserErrorString()}", error=True)
            return

        request = QgsFeatureRequest(expr)
        selected_feats = [f for f in poly_layer.getFeatures(request)]

        if not selected_feats:
            self._msg("Bu filtreye uyan alan bulunamadı.", error=True)
            return

        poly_layer.removeSelection()
        poly_layer.selectByIds([f.id() for f in selected_feats])

        poly_layer_name = "alan_poligon"

        transform_context = project.transformContext()
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = "GPKG"
        options.fileEncoding = "UTF-8"
        options.layerName = poly_layer_name
        options.onlySelectedFeatures = True

        if os.path.exists(gpkg_path):
            os.remove(gpkg_path)

        res, error_message, new_layer, _ = QgsVectorFileWriter.writeAsVectorFormatV3(
            poly_layer,
            gpkg_path,
            transform_context,
            options
        )

        if res != QgsVectorFileWriter.NoError:
            self._msg(f"GPKG yazılırken hata: {error_message}", error=True)
            return

        poly_uri = f"{gpkg_path}|layername={poly_layer_name}"
        ilce_layer = QgsVectorLayer(poly_uri, poly_layer_name, "ogr")

        if not ilce_layer.isValid():
            self._msg("alan poligon katmanı GPKG'den yüklenemedi.", error=True)
            return

        project.addMapLayer(ilce_layer)

        # ------------------------------------------------------------------
        # İLÇE/İL POLİGONU SINIR STİLİ — KALIN KIRMIZI 
        # ------------------------------------------------------------------
        symbol = ilce_layer.renderer().symbol()

        # Poligon dolgusunu tamamen şeffaf yap
        symbol.setColor(QColor(0, 0, 0, 0))

        # Outline (stroke) ayarı
        outline = symbol.symbolLayer(0)  # ilk layer outline'dır

        outline.setStrokeColor(QColor(255, 0, 0))  # kırmızı
        outline.setStrokeWidth(2.0)                # 2 px
        # 4 px istersen 4.0 yaparsın

        # Güncelle
        ilce_layer.triggerRepaint()

        # ------------------------------------------------------------------
        # 3) DEM'İ İLÇEYE GÖRE CLIPLE
        # ------------------------------------------------------------------
        feedback = QgsProcessingFeedback()

        dem_clip_layer_name = "dem_clip"
        dem_clip_out = os.path.join(out_folder, f"{safe_name}_dem_clip.tif")

        clip_params = {
            "INPUT": dem_layer,
            "MASK": ilce_layer,
            "SOURCE_CRS": dem_layer.crs(),
            "TARGET_CRS": dem_layer.crs(),
            "CROP_TO_CUTLINE": True,
            "KEEP_RESOLUTION": True,
            "NODATA": None,
            "ALPHA_BAND": False,
            "OPTIONS": "",
            "DATA_TYPE": 0,
            "OUTPUT": dem_clip_out
        }

        try:
            clip_result = processing.run("gdal:cliprasterbymasklayer", clip_params, feedback=feedback)
        except Exception as e:
            self._msg(f"DEM clip sırasında hata: {e}", error=True)
            return

        dem_clip_path = clip_result["OUTPUT"]
        dem_clip_layer = QgsRasterLayer(dem_clip_path, dem_clip_layer_name)

        if not dem_clip_layer.isValid():
            self._msg("DEM clip sonucu raster katmanı yüklenemedi.", error=True)
            return

        # ------------------------------------------------------------------
        # 4) DEM RENKLENDİRME — NATURAL BREAKS (JENKS) + TERRAIN RENKLERİ
        # ------------------------------------------------------------------
        provider = dem_clip_layer.dataProvider()
        stats = provider.bandStatistics(1)
        min_val = stats.minimumValue
        max_val = stats.maximumValue

        # Raster örnekleme (performans için 120x120 blok)
        values = []
        block = provider.block(1, dem_clip_layer.extent(), 120, 120)
        nodata = provider.sourceNoDataValue(1)

        for x in range(block.width()):
            for y in range(block.height()):
                v = block.value(x, y)
                if v != nodata:
                    values.append(v)

        values.sort()

        def jenks_breaks(data_list, num_class):
            """Raster değerleri için Jenks (Natural Breaks) sınıflama."""
            n = len(data_list)
            if n == 0 or n < num_class:
                return []

            matrices = [[0 for _ in range(num_class + 1)] for _ in range(n + 1)]
            variance = [[0 for _ in range(num_class + 1)] for _ in range(n + 1)]

            for i in range(1, num_class + 1):
                matrices[1][i] = 1
                variance[1][i] = 0
                for j in range(2, n + 1):
                    variance[j][i] = float("inf")

            for l in range(2, n + 1):
                sum_val = 0.0
                sum_sq = 0.0
                w = 0
                for m in range(1, l + 1):
                    i3 = l - m + 1
                    val = data_list[i3 - 1]
                    w += 1
                    sum_val += val
                    sum_sq += val * val
                    var_calc = sum_sq - (sum_val * sum_val) / w
                    i4 = i3 - 1
                    if i4 != 0:
                        for j in range(2, num_class + 1):
                            if variance[l][j] >= variance[i4][j - 1] + var_calc:
                                matrices[l][j] = i3
                                variance[l][j] = variance[i4][j - 1] + var_calc
                matrices[l][1] = 1
                variance[l][1] = var_calc

            breaks = [0] * (num_class + 1)
            breaks[num_class] = data_list[-1]
            count_class = num_class
            k = n

            while count_class >= 2:
                idx = int(matrices[k][count_class] - 2)
                breaks[count_class - 1] = data_list[idx]
                k = int(matrices[k][count_class] - 1)
                count_class -= 1

            breaks[0] = data_list[0]
            return breaks

        items = []
        if len(values) >= 5:
            class_breaks = jenks_breaks(values, 5)

            colors = [
                QColor(168, 230, 161),   # Açık yeşil
                QColor(46, 139, 87),     # Koyu yeşil
                QColor(210, 180, 140),   # Açık kahve
                QColor(139, 69, 19),     # Koyu kahve
                QColor(255, 255, 255)    # Beyaz
            ]

            for i in range(5):
                items.append(
                    QgsColorRampShader.ColorRampItem(
                        class_breaks[i],
                        colors[i],
                        f"class_{i+1}"
                    )
                )
        else:
            # Jenks için yeterli veri yoksa fallback: min-max aralığını eşit böl
            step = (max_val - min_val) / 5 if max_val > min_val else 1
            raw_breaks = [min_val + i * step for i in range(5)]
            colors = [
                QColor(168, 230, 161),
                QColor(46, 139, 87),
                QColor(210, 180, 140),
                QColor(139, 69, 19),
                QColor(255, 255, 255)
            ]
            for i in range(5):
                items.append(
                    QgsColorRampShader.ColorRampItem(
                        raw_breaks[i],
                        colors[i],
                        f"class_{i+1}"
                    )
                )

        shader = QgsRasterShader()
        color_ramp = QgsColorRampShader()
        color_ramp.setColorRampType(QgsColorRampShader.Interpolated)
        color_ramp.setColorRampItemList(items)
        shader.setRasterShaderFunction(color_ramp)

        renderer = QgsSingleBandPseudoColorRenderer(
            dem_clip_layer.dataProvider(),
            1,
            shader
        )

        dem_clip_layer.setRenderer(renderer)
        dem_clip_layer.renderer().setOpacity(0.76)
        dem_clip_layer.triggerRepaint()

        project.addMapLayer(dem_clip_layer)

        # ------------------------------------------------------------------
        # 5) HILLSHADE OLUŞTUR
        # ------------------------------------------------------------------
        hill_layer_name = "hillshade"
        hill_out = os.path.join(out_folder, f"{safe_name}_hillshade.tif")

        hill_params = {
            "INPUT": dem_clip_layer,
            "Z_FACTOR": 1.0,
            "SCALE": 1.0,
            "AZIMUTH": 315.0,
            "ALTITUDE": 45.0,
            "COMPUTE_EDGES": True,
            "ZEVENBERGEN": False,
            "MULTIDIRECTIONAL": False,
            "OPTIONS": "",
            "OUTPUT": hill_out
        }

        try:
            hill_result = processing.run("gdal:hillshade", hill_params, feedback=feedback)
        except Exception as e:
            self._msg(f"Hillshade sırasında hata: {e}", error=True)
            return

        hill_path = hill_result["OUTPUT"]
        hill_layer = QgsRasterLayer(hill_path, hill_layer_name)

        if not hill_layer.isValid():
            self._msg("Hillshade raster katmanı yüklenemedi.", error=True)
            return

        project.addMapLayer(hill_layer)

        # ------------------------------------------------------------------
        # 6) KATMAN GÖRÜNÜRLÜKLERİ + SIRALAMA
        # ------------------------------------------------------------------
        root = project.layerTreeRoot()

        for child in root.children():
            if hasattr(child, "setItemVisibilityChecked"):
                child.setItemVisibilityChecked(False)

        node_ilce = root.findLayer(ilce_layer.id())
        node_dem = root.findLayer(dem_clip_layer.id())
        node_hill = root.findLayer(hill_layer.id())

        if node_ilce:
            node_ilce.setItemVisibilityChecked(True)
        if node_dem:
            node_dem.setItemVisibilityChecked(True)
        if node_hill:
            node_hill.setItemVisibilityChecked(True)

        root.insertLayer(0, dem_clip_layer)
        root.insertLayer(1, hill_layer)
        root.insertLayer(2, ilce_layer)

        # ------------------------------------------------------------------
        # 7) LAYOUT OLUŞTUR — A4, FRAME TAM SAYFA, İÇTE 5 MM BOŞLUK
        # ------------------------------------------------------------------
        layout_name = f"GeoRehber İlçe Layout - {safe_name}"
        layout_manager = project.layoutManager()

        for l in layout_manager.layouts():
            if l.name() == layout_name:
                layout_manager.removeLayout(l)
                break

        layout = QgsPrintLayout(project)
        layout.initializeDefaults()
        layout.setName(layout_name)
        layout_manager.addLayout(layout)

        # Sayfa: A4 yatay, margin 0
        page = layout.pageCollection().pages()[0]
        page.setPageSize("A4", QgsLayoutItemPage.Orientation.Landscape)
        
        # İlçe extent'ini A4 oranına göre pad et (auto-fit)
        ext = ilce_layer.extent()
        minx, miny, maxx, maxy = ext.xMinimum(), ext.yMinimum(), ext.xMaximum(), ext.yMaximum()
        width = maxx - minx
        height = maxy - miny

        ratio_map = width / height if height != 0 else 1
        ratio_a4 = 297 / 210  # A4 yatay

        if ratio_map < ratio_a4:
            # Harita daha dik → genişlik artırılacak
            new_width = height * ratio_a4
            pad = (new_width - width) / 2
            minx -= pad
            maxx += pad
        else:
            # Harita daha yatay → yükseklik artırılacak
            new_height = width / ratio_a4 if ratio_a4 != 0 else height
            pad = (new_height - height) / 2
            miny -= pad
            maxy += pad

        adjusted_extent = QgsRectangle(minx, miny, maxx, maxy)

        # Map item oluştur
        map_item = QgsLayoutItemMap(layout)
        map_item.setFrameEnabled(True)
        map_item.setFrameStrokeWidth(QgsLayoutMeasurement(0.8))

        # Map frame: tam A4 (0,0)-(297x210)
        map_item.attemptMove(QgsLayoutPoint(0, 0, QgsUnitTypes.LayoutMillimeters))
        map_item.attemptResize(QgsLayoutSize(297, 210, QgsUnitTypes.LayoutMillimeters))

        # İçte 5 mm boşluk olacak şekilde extent'i biraz büyüt
        pad_x = (adjusted_extent.width() * 5) / 297
        pad_y = (adjusted_extent.height() * 5) / 210

        inner_extent = QgsRectangle(
            adjusted_extent.xMinimum() - pad_x,
            adjusted_extent.yMinimum() - pad_y,
            adjusted_extent.xMaximum() + pad_x,
            adjusted_extent.yMaximum() + pad_y
        )

        map_item.setExtent(inner_extent)

        layout.addLayoutItem(map_item)
        
        # ------------------------------------------------------------------
        # 8) LAYOUT EKLERİ — YÖN OKU, ÖLÇEK ÇUBUĞU, LEJANT
        # ------------------------------------------------------------------
        # A4 yatay boyutları: 297 x 210 mm
        margin = 8  # kenarlardan boşluk (mm)

        # 8.1 — YÖN OKU (sol üst köşe)
        north_item = QgsLayoutItemPicture(layout)

        # QGIS'teki SVG klasörlerini al
        svg_dirs = QgsApplication.svgPaths()

        # İlk svg klasörünün içindeki siyah yön oku
        north_svg_path = svg_dirs[0] + "/arrows/NorthArrow_04.svg"

        if os.path.exists(north_svg_path):
            north_item.setPicturePath(north_svg_path)

        north_item.attemptResize(
            QgsLayoutSize(25, 25, QgsUnitTypes.LayoutMillimeters)
        )
        north_item.attemptMove(
            QgsLayoutPoint(margin, margin, QgsUnitTypes.LayoutMillimeters)
        )
        # ================================
        #   SVG FILL RENK DÜZENLEME (GARANTİ)
        # ================================
        import tempfile
        import re

        north_svg_original = north_svg_path

        # Geçici SVG oluştur
        temp_svg = os.path.join(tempfile.gettempdir(), "northarrow_custom.svg")

        # Orijinal SVG'yi oku
        with open(north_svg_original, "r", encoding="utf-8") as f:
            svg_data = f.read()

        # Tüm fill renklerini siyaha çevir
        svg_data = re.sub(r'fill="[^"]+"', 'fill="#000000"', svg_data)
        svg_data = re.sub(r'fill:[^;"]+', 'fill:#000000', svg_data)

        # Düzenlenmiş SVG’yi yaz
        with open(temp_svg, "w", encoding="utf-8") as f:
            f.write(svg_data)

        # QGIS’e siyaha çevrilmiş SVG'yi yükle
        north_item.setPicturePath(temp_svg)

        # Layout'a ekle (bunu en son yaz)
        layout.addLayoutItem(north_item)



        # 8.2 — ÖLÇEK ÇUBUĞU (sol alt köşe)
        scale_item = QgsLayoutItemScaleBar(layout)
        scale_item.setLinkedMap(map_item)
        scale_item.setStyle("Single Box")
        scale_item.applyDefaultSize()

        # Yükseklik bilgisini aldıktan sonra alt köşeye yerleştir
        scale_height = scale_item.rect().height()
        scale_item.attemptMove(
            QgsLayoutPoint(
                margin,
                210 - margin - scale_height,
                QgsUnitTypes.LayoutMillimeters
            )
        )
        layout.addLayoutItem(scale_item)

               # 8.3 — LEJANT (sağ üst köşe)

        legend_item = QgsLayoutItemLegend(layout)
        legend_item.setTitle("Lejant")
        legend_item.setLinkedMap(map_item)

        # Modeli elle düzenleyeceğiz
        legend_item.setAutoUpdateModel(False)

        layout.addLayoutItem(legend_item)

        model = legend_item.model()
        root = model.rootGroup()

        # ------------------------------------------------------------
        # SADECE 2 ÖĞE KALSIN:
        # 1) Yükseklik (metre)
        # 2) <value_text> Sınırı
        # ------------------------------------------------------------

        for child in list(root.children()):
            name = child.name().lower()

            # --- POLİGON ---
            if "alan" in name or "poligon" in name:
                child.setName(value_text + " Sınırı")

                # Alt node'ları collapse et
                for sub in child.children():
                    sub.setExpanded(False)

                continue

            # --- DEM / CLIP ---
            if "dem" in name or "clip" in name:
                child.setName("Yükseklik (metre)")

                continue

            # --- DİĞER TÜM LAYERLAR LEJANTTAN SİLİNİR ---
            root.removeChildNode(child)

        # ------------------------------------------------------------
        #  SAĞ ÜST KÖŞE HİZALAMA — TAŞMAYI ÖNLEYEN GERÇEK ÇÖZÜM
        # ------------------------------------------------------------

        # 1) Lejantı yeniden hesaplat
        legend_item.updateLegend()
        legend_item.adjustBoxSize()
        legend_item.adjustBoxSize()   # QGIS 3.44 bug fix (ikinci kez)

        # 2) Genişliği manuel sınırlıyoruz (A4 taşmasın diye)
        max_width = 60  # mm — ideal sağ üst hizalama genişliği
        legend_height = legend_item.rect().height()

        legend_item.attemptResize(
            QgsLayoutSize(
                max_width,
                legend_height,
                QgsUnitTypes.LayoutMillimeters
            )
        )

        # 3) Son tam hizalama (sağ üst)
        legend_item.attemptMove(
            QgsLayoutPoint(
                297 - 8 - max_width,    # Sayfa genişliği - margin - legend genişliği
                8,                      # Üstten margin
                QgsUnitTypes.LayoutMillimeters
            )
        )


        # Layout penceresini aç
        self.iface.openLayoutDesigner(layout)
        self._msg(f"İşlem tamam. GPKG:\n{gpkg_path}", error=False)

    def _sanitize_name(self, name: str) -> str:
        """alan adını dosya ismine uygun, temiz bir forma çevir."""
        tr_map = str.maketrans(
            "çğıöşüÇĞİÖŞÜ ",
            "cgiosuCGIOSU_"
        )
        cleaned = name.translate(tr_map)
        cleaned = re.sub(r"[^A-Za-z0-9_]+", "_", cleaned)
        cleaned = re.sub(r"_+", "_", cleaned).strip("_")
        if not cleaned:
            cleaned = "ilce"
        return cleaned

    def _msg(self, text, error=False):
        level = Qgis.Critical if error else Qgis.Info
        self.iface.messageBar().pushMessage("GeoRehber", text, level, duration=6)
        if error:
            QMessageBox.warning(self.iface.mainWindow(), "GeoRehber Lokasyon Haritası", text)
